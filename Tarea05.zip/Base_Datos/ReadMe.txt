Esta carpeta debe contener los archivos, documentaci�n, scripts y 
cualquier otro relacionado a la Base de datos Prog04_Proj02.