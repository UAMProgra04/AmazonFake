Esta carpeta debe contener los archivos, documentaci�n, scripts y 
cualquier otro relacionado al proyecto de Visual Studio.